<?php 
return[
    'dsn' => 'mysql:host=localhost;dbname=school;charset=utf8mb4',
    'user' => 'demouser',
    'password' => 'Kiwi'
];
?>